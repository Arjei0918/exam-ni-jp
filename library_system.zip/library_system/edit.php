
<?php
require_once "db.php";

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(400);
    exit("Invalid book ID.");
}

$stmt = $conn->prepare(
    "SELECT title, author, isbn, published_year
     FROM books WHERE id = ?"
);
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($title, $author, $isbn, $published_year);

if (!$stmt->fetch()) {
    $stmt->close();
    $conn->close();
    http_response_code(404);
    exit("Book not found.");
}
$stmt->close();

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST["title"] ?? "");
    $author = trim($_POST["author"] ?? "");
    $isbn = trim($_POST["isbn"] ?? "");
    $published_year = trim($_POST["published_year"] ?? "");

    if (
        $title === "" || $author === "" ||
        $isbn === "" || $published_year === ""
    ) {
        $error = "All fields are required.";
    } elseif (
        !preg_match('/^\d{1,4}$/', $published_year) ||
        (int)$published_year < 1
    ) {
        $error = "Enter a valid published year.";
    } else {
        try {
            $year = (int)$published_year;

            $stmt = $conn->prepare(
                "UPDATE books
                 SET title = ?, author = ?, isbn = ?,
                     published_year = ?
                 WHERE id = ?"
            );
            $stmt->bind_param(
                "sssii",
                $title, $author, $isbn, $year, $id
            );
            $stmt->execute();
            $stmt->close();
            $conn->close();

            header("Location: index.php");
            exit;
        } catch (mysqli_sql_exception $ex) {
            $error = "Update failed. Check whether the ISBN already exists.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Book</title>
</head>
<body>

<h2>Edit Book</h2>

<?php if ($error !== ""): ?>
    <p style="color:red"><?= e($error) ?></p>
<?php endif; ?>

<form method="POST">
    <label>Title:</label><br>
    <input name="title" maxlength="150"
           value="<?= e($title) ?>" required><br><br>

    <label>Author:</label><br>
    <input name="author" maxlength="100"
           value="<?= e($author) ?>" required><br><br>

    <label>ISBN:</label><br>
    <input name="isbn" maxlength="20"
           value="<?= e($isbn) ?>" required><br><br>

    <label>Published Year:</label><br>
    <input type="number" name="published_year"
           min="1" max="9999"
           value="<?= e($published_year) ?>" required><br><br>

    <button type="submit">Update Book</button>
    <a href="index.php">Cancel</a>
</form>

</body>
</html>
