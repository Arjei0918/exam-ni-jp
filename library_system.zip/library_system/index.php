
<?php
require_once "db.php";

$sql = "SELECT * FROM books ORDER BY id DESC";
$result = $conn->query($sql);

if (!$result) {
    die("Failed to retrieve books.");
}

function e($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Library Book Inventory</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background: #f4f6f9;
        }
        h2 { text-align: center; }
        a.button {
            display: inline-block;
            padding: 9px 14px;
            background: #1877c9;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }
        th { background: #e5edf5; }
    </style>
</head>
<body>

<h2>Library Book Inventory System</h2>

<a class="button" href="create.php">Add New Book</a>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Author</th>
            <th>ISBN</th>
            <th>Published Year</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php while ($book = $result->fetch_assoc()): ?>
        <tr>
            <td><?= e($book["id"]) ?></td>
            <td><?= e($book["title"]) ?></td>
            <td><?= e($book["author"]) ?></td>
            <td><?= e($book["isbn"]) ?></td>
            <td><?= e($book["published_year"]) ?></td>
            <td>
                <a href="edit.php?id=<?= (int)$book["id"] ?>">
                    Edit
                </a>
                |
                <a href="delete.php?id=<?= (int)$book["id"] ?>"
                   onclick="return confirm('Delete this book?');">
                    Delete
                </a>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

</body>
</html>

<?php
$result->free();
$conn->close();
?>
