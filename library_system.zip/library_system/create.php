
<?php
require_once "db.php";

$title = "";
$author = "";
$isbn = "";
$published_year = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = trim($_POST["title"] ?? "");
    $author = trim($_POST["author"] ?? "");
    $isbn = trim($_POST["isbn"] ?? "");
    $published_year = trim($_POST["published_year"] ?? "");

    if (
        $title === "" ||
        $author === "" ||
        $isbn === "" ||
        $published_year === ""
    ) {
        $error = "All fields are required.";
    } elseif (
        !preg_match('/^\d{1,4}$/', $published_year) ||
        (int)$published_year < 1
    ) {
        $error = "Enter a valid published year.";
    } else {
        try {
            $stmt = $conn->prepare(
                "INSERT INTO books
                (title, author, isbn, published_year)
                VALUES (?, ?, ?, ?)"
            );

            $year = (int)$published_year;
            $stmt->bind_param(
                "sssi",
                $title,
                $author,
                $isbn,
                $year
            );

            $stmt->execute();
            $stmt->close();
            $conn->close();

            header("Location: index.php");
            exit;
        } catch (mysqli_sql_exception $ex) {
            $error = "Could not add book. Check whether the ISBN already exists.";
        }
    }
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Book</title>
</head>
<body>

<h2>Add New Book</h2>

<?php if ($error !== ""): ?>
    <p style="color:red"><?= e($error) ?></p>
<?php endif; ?>

<form method="POST">
    <label>Title:</label><br>
    <input type="text" name="title" maxlength="150"
           value="<?= e($title) ?>" required><br><br>

    <label>Author:</label><br>
    <input type="text" name="author" maxlength="100"
           value="<?= e($author) ?>" required><br><br>

    <label>ISBN:</label><br>
    <input type="text" name="isbn" maxlength="20"
           value="<?= e($isbn) ?>" required><br><br>

    <label>Published Year:</label><br>
    <input type="number" name="published_year"
           min="1" max="9999"
           value="<?= e($published_year) ?>" required><br><br>

    <button type="submit">Save Book</button>
    <a href="index.php">Cancel</a>
</form>

</body>
</html>
