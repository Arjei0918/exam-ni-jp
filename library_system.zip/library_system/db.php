
<?php
mysqli_report(MYSQLI_REPORT_OFF);

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "library_db"
);

if ($conn->connect_error) {
    die("Database connection failed: " .
        htmlspecialchars($conn->connect_error));
}

if (!$conn->set_charset("utf8mb4")) {
    die("Failed to set database charset.");
}
?>
